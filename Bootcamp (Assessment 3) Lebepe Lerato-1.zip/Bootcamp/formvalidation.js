function validate()
{

if (document.myform.fullnames.value=="")
	{
	alert("Name and surname required");
	myform.fullnames.focus();
	return false;
	}


if (document.myform.email.value=="")
	{
	alert("E-mail required");
	myform.email.focus();
	return false;
	}
	
if (document.myform.message.value=="")
	{
	alert("Message required");
	myform.message.focus();
	return false;
	}	

document.write("Message sent sucessfully!")	
}
